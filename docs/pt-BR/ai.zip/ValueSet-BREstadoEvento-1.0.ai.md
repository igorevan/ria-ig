# Estado do Evento - Guia de Implementação do Registro de Imunobiológico Administrado (RIA) da RNDS v1.0.0-release

## ValueSet: Estado do Evento 

 
Identificação do estado de um evento. 

 **References** 

* [Imunobiológico Administrado em Rotina](StructureDefinition-BRImunobiologicoAdministrado-3.0.md)

### Logical Definition (CLD)

 

### 

No Expansion for this valueset (Unsupported Code System Version)

-------

 . 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BREstadoEvento-1.0",
  "language" : "en",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/ria/1.0.0/ImplementationGuide/br.gov.saude.ria.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/ria/1.0.0/ImplementationGuide/br.gov.saude.ria.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/ValueSet/BREstadoEvento-1.0",
  "version" : "1.0.0-release",
  "name" : "BREstadoEvento",
  "title" : "Estado do Evento",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-04-07T12:14:07.8417018+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Identificação do estado de um evento.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "immutable" : false,
  "compose" : {
    "include" : [{
      "system" : "http://hl7.org/fhir/event-status",
      "version" : "*",
      "concept" : [{
        "code" : "preparation",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Pré-procedimento"
        }]
      },
      {
        "code" : "in-progress",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Em andamento"
        }]
      },
      {
        "code" : "not-done",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Não Realizado"
        }]
      },
      {
        "code" : "on-hold",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Suspenso"
        }]
      },
      {
        "code" : "stopped",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Cancelado"
        }]
      },
      {
        "code" : "completed",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Completado"
        }]
      },
      {
        "code" : "unknown",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Desconhecido"
        }]
      },
      {
        "code" : "entered-in-error",
        "designation" : [{
          "language" : "pt-BR",
          "value" : "Entrada com erro"
        }]
      }]
    }]
  }
}

```
