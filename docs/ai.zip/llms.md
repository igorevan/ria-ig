# br.gov.saude.ria.fhir#0.1.0: Guia de Implementação do Registro de Imunobiológico Administrado (RIA) da RNDS

## Pages

* [Principal](index.md)
* [Modelo Computacional](mcRiar.md)
* [Segurança](seguranca.md)
* [Histórico de mudanças](changes.md)
* [Artifacts Summary](artifacts.md)
* [Modelo de Informação](miRiar.md)
* [Useful Downloads](downloads.md)
* [Modelo de Informação](miRiac.md)
* [Integração](integracao.md)
* [Modelo Computacional](mcRiac.md)
* [Exemplos](exemplos.md)
* [Credenciamento](credenciamento.md)

## Resources

### CodeSystems

* [Classificação Brasileira de Ocupações (CBO)](CodeSystem-BRCBO.md)
* [Classificação Internacional de Doenças - Décima Revisão (CID-10)](CodeSystem-BRCID10.md)
* [Categoria do Diagnóstico](CodeSystem-BRCategoriaDiagnostico.md)
* [Condição Maternal](CodeSystem-BRCondicaoMaternal.md)
* [Dose de Vacina](CodeSystem-BRDose.md)
* [Estratégia de Vacinação](CodeSystem-BREstrategiaVacinacao.md)
* [Fabricante do Imunobiológico](CodeSystem-BRFabricantePNI.md)
* [Grupo de Atendimento](CodeSystem-BRGrupoAtendimento.md)
* [Imunobiológico](CodeSystem-BRImunobiologico.md)
* [Local de Aplicação](CodeSystem-BRLocalAplicacao.md)
* [País](CodeSystem-BRPais.md)
* [Registro de Origem](CodeSystem-BRRegistroOrigem.md)
* [Tipo de Documento](CodeSystem-BRTipoDocumento.md)
* [Via de Administração](CodeSystem-BRViaAdministracao.md)

### ValueSets

* [Classificação Internacional de Doenças - Décima Revisão (CID-10)](ValueSet-BRCID10-1.0.md)
* [Categoria do Diagnóstico](ValueSet-BRCategoriaDiagnostico.md)
* [Condição Maternal](ValueSet-BRCondicaoMaternal-1.0.md)
* [Dose do Imunobiológico](ValueSet-BRDose-1.0.md)
* [Estado do Evento](ValueSet-BREstadoEvento-1.0.md)
* [Estado da Resolução de Diagnóstico ou Problema](ValueSet-BREstadoResolucaoDiagnosticoProblema-1.0.md)
* [Estratégia de Vacinação](ValueSet-BREstrategiaVacinacao-1.0.md)
* [Fabricante do Imunobiológico](ValueSet-BRFabricanteImunobiologico-1.0.md)
* [Tipo de grupo de atendimento](ValueSet-BRGrupoAtendimento-1.0.md)
* [Imunobiológico](ValueSet-BRImunobiologico-1.0.md)
* [Local de Aplicação](ValueSet-BRLocalAplicacao-1.0.md)
* [Classificação Brasileira de Ocupações (CBO)](ValueSet-BROcupacao-1.0.md)
* [País](ValueSet-BRPais-1.0.md)
* [Registro de Origem](ValueSet-BRRegistroOrigem.md)
* [Tipo de Documento](ValueSet-BRTipoDocumento-1.0.md)
* [Via de Administração do Imunobiológico](ValueSet-BRViaAdministracao-1.0.md)

### Resource Profiles

* [CID10 Avaliado](StructureDefinition-BRCID10Avaliado-1.0.md)
* [Imunobiológico Administrado em Rotina](StructureDefinition-BRImunobiologicoAdministrado-3.0.md)
* [Imunobiológico Administrado em Campanha](StructureDefinition-BRImunobiologicoAdministradoCampanha-2.0.md)
* [Registro de Imunobiológico Administrado na Campanha](StructureDefinition-BRRegistroImunobiologicoAdministradoCampanha-2.0.md)
* [Registro de Imunobiológico Administrado na Rotina](StructureDefinition-BRRegistroImunobiologicoAdministradoRotina-2.0.md)

### Extensions

* [Condição Maternal](StructureDefinition-BRCondicaoMaternal.md)
* [Contato Hanseníase](StructureDefinition-BRContatoHanseniase.md)
* [Estratégia de Vacinação](StructureDefinition-BREstrategiaVacinacao-1.0.md)
* [Estratégia de Vacinação Pesquisa](StructureDefinition-BREstrategiaVacinacaoPesquisa-1.0.md)
* [Grupo de Atendimento](StructureDefinition-BRGrupoAtendimento.md)

### ImplementationGuides

* [Guia de Implementação do Registro de Imunobiológico Administrado (RIA) da RNDS](index.md)

### Examples

* [example-RIA-C (Bundle)](Bundle-example-RIA-C.md)
* [example-RIA-R (Bundle)](Bundle-example-RIA-R.md)
