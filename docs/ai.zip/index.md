# Principal - Guia de Implementação do Registro de Imunobiológico Administrado (RIA) da RNDS v0.1.0

* [**Índice**](toc.md)
* **Principal**

## Principal

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://www.saude.gov.br/fhir/r4/ImplementationGuide/br.gov.saude.ria.fhir | *Version*:0.1.0 | |
| *IG Standards status:*[Informative](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:RIARNDSIG |

### Introdução

 Este Guia de Implementação (IG) tem o objetivo de orientar Estados, Municípios, Distrito Federal, Estabelecimentos de Saúde ou Empresas Privadas que fornecem soluções/software na área de saúde a utilizarem os serviços *(web services)* que foram desenvolvidos para a [Rede Nacional de Dados em Saúde (RNDS)](https://www.gov.br/saude/pt-br/composicao/seidigi/rnds), fornecendo as orientações técnicas necessárias para a integração dos sistemas/soluções locais com a rede, para o envio do [Registro de Imunobiológico Administrado (RIA)](https://servicos-datasus.saude.gov.br/detalhe/urB3hXWTee) seguindo as especificações do padrão [HL7 FHIR versão R4](https://hl7.org/fhir/R4/). 

### Contextualização

 A RNDS é uma plataforma nacional de integração de dados em saúde que faz parte do [Meu SUS Digital](https://www.gov.br/saude/pt-br/composicao/seidigi/meu-sus-digital), um programa do Governo Federal que tem como principal missão materializar a [Estratégia de Saúde Digital do Brasil](https://bvsms.saude.gov.br/bvs/publicacoes/estrategia_saude_digital_Brasil.pdf). 

 A RNDS utiliza computação em nuvem e tecnologias emergentes para criar um repositório de documentos responsável por armazenar informações de saúde dos cidadãos, mantendo a privacidade, integridade e auditabilidade dos dados de maneira acessível e interoperável. Com isso, fornece aos profissionais de saúde acesso à história clínica do paciente, permitindo a transição e a continuidade do cuidado, além de possibilitar aos indivíduos acesso aos seus dados de saúde. 

 Dessa forma, os serviços (*web services*) permitirão que as entidades da área da saúde compartilhem as informações do Registro de Imunobiológico Administrado (RIA) com a RNDS de forma oportuna e confiável a quem precisa desta informação. 

### Interoperabilidade

 Para garantir a interoperabilidade entre as aplicações de Saúde Digital, em especial Prontuário(s) Eletrônico(s) do Paciente, portais e aplicações (*web e mobile*), a troca de informações ocorre por meio de serviços (*web services*) [RESTful](https://pt.wikipedia.org/wiki/REST), desenvolvidos de acordo com o padrão [FHIR R4](https://hl7.org/FHIR/). 

### Roteiro

*  [Credenciamento](credenciamento.md): Saiba qual é o processo e requisitos a serem seguidos por um estabelecimento de saúde para a integração com a RNDS. 
*  [Segurança](seguranca.md): Orienta como todas as transações devem ser protegidas. 
*  [Integração](integracao.md): Define as operações a serem atendidas para integração com a RNDS. 
*  [Modelo de Informação (RIA-C)](miRiac.md): Define o Modelo de Informação (MI) do RIA-C. 
*  [Modelo Computacional (RIA-C)](mcRiac.md): Define o Modelo Computacional (MC) do RIA-C. 
*  [Modelo de Informação (RIA-R)](miRiar.md): Define o Modelo de Informação (MI) do RIA-R. 
*  [Modelo Computacional (RIA-R)](mcRiar.md): Define o Modelo Computacional (MC) do RIA-R. 
*  [Artefatos](artifacts.md): Reúne todos os recursos *(Resources)* do FHIR para elaboração dos Modelos Computacionais do RIA. 
*  [Exemplos](exemplos.md): Instâncias de exemplos. 
*  [Downloads](downloads.md): Artefatos empregados pelos integradores. 

