# br.gov.saude.ria.fhir#1.0.0-release: Guia de Implementação do Registro de Imunobiológico Administrado (RIA) da RNDS(en)

## Pages

* [Principal](index.md)
* [Credenciamento](credenciamento.md)
* [Downloads](downloads.md)
* [Suporte da RNDS](suporte.md)
* [Modelo Computacional](mcRiar.md)
* [Feedback](forms.md)
* [Modelo de Informação](miRiar.md)
* [Integração](integracao.md)
* [Artifacts Summary](artifacts.md)
* [Histórico de mudanças](changes.md)
* [Exemplos](exemplos.md)

## Resources

### CodeSystems

* [Classificação Brasileira de Ocupações - CBO (CodeSystem)](CodeSystem-BRCBO.md)
* [Classificação Internacional de Doenças - Décima Revisão - CID-10 (CodeSystem)](CodeSystem-BRCID10.md)
* [Categoria do Diagnóstico (CodeSystem)](CodeSystem-BRCategoriaDiagnostico.md)
* [Condição Maternal (CodeSystem)](CodeSystem-BRCondicaoMaternal.md)
* [Dose de Vacina](CodeSystem-BRDose.md)
* [Estratégia de Vacinação (CodeSystem)](CodeSystem-BREstrategiaVacinacao.md)
* [Fabricante do Imunobiológico (CodeSystem)](CodeSystem-BRFabricantePNI.md)
* [Grupo de Atendimento (CodeSystem)](CodeSystem-BRGrupoAtendimento.md)
* [Imunobiológico (CodeSystem)](CodeSystem-BRImunobiologico.md)
* [Local de Aplicação (CodeSystem)](CodeSystem-BRLocalAplicacao.md)
* [País (CodeSystem)](CodeSystem-BRPais.md)
* [Registro de Origem (CodeSystem)](CodeSystem-BRRegistroOrigem.md)
* [Tipo de Documento (CodeSystem)](CodeSystem-BRTipoDocumento.md)
* [Via de Administração](CodeSystem-BRViaAdministracao.md)

### ValueSets

* [Classificação Internacional de Doenças - Décima Revisão - CID-10 (ValueSet)](ValueSet-BRCID10-1.0.md)
* [Categoria do Diagnóstico (ValueSet)](ValueSet-BRCategoriaDiagnostico.md)
* [Condição Maternal (ValueSet)](ValueSet-BRCondicaoMaternal-1.0.md)
* [Dose do Imunobiológico](ValueSet-BRDose-1.0.md)
* [Estado do Evento](ValueSet-BREstadoEvento-1.0.md)
* [Estado da Resolução de Diagnóstico ou Problema](ValueSet-BREstadoResolucaoDiagnosticoProblema-1.0.md)
* [Estratégia de Vacinação (ValueSet)](ValueSet-BREstrategiaVacinacao-1.0.md)
* [Fabricante do Imunobiológico (ValueSet)](ValueSet-BRFabricanteImunobiologico-1.0.md)
* [Tipo de grupo de atendimento (ValueSet)](ValueSet-BRGrupoAtendimento-1.0.md)
* [Imunobiológico (ValueSet)](ValueSet-BRImunobiologico-1.0.md)
* [Local de Aplicação (ValueSet)](ValueSet-BRLocalAplicacao-1.0.md)
* [Classificação Brasileira de Ocupações - CBO (ValueSet)](ValueSet-BROcupacao-1.0.md)
* [País (ValueSet)](ValueSet-BRPais-1.0.md)
* [Registro de Origem (ValueSet)](ValueSet-BRRegistroOrigem.md)
* [Tipo de Documento (ValueSet)](ValueSet-BRTipoDocumento-1.0.md)
* [Via de Administração do Imunobiológico](ValueSet-BRViaAdministracao-1.0.md)

### Resource Profiles

* [CID10 Avaliado](StructureDefinition-BRCID10Avaliado-1.0.md)
* [Imunobiológico Administrado em Rotina](StructureDefinition-BRImunobiologicoAdministrado-3.0.md)
* [Registro de Imunobiológico Administrado na Rotina](StructureDefinition-BRRegistroImunobiologicoAdministradoRotina-2.0.md)

### Extensions

* [Condição Maternal](StructureDefinition-BRCondicaoMaternal.md)
* [Contato Hanseníase](StructureDefinition-BRContatoHanseniase.md)
* [Estratégia de Vacinação](StructureDefinition-BREstrategiaVacinacao-1.0.md)
* [Estratégia de Vacinação Pesquisa](StructureDefinition-BREstrategiaVacinacaoPesquisa-1.0.md)
* [Grupo de Atendimento](StructureDefinition-BRGrupoAtendimento.md)

### ImplementationGuides

* [Guia de Implementação do Registro de Imunobiológico Administrado (RIA) da RNDS](ImplementationGuide-br.gov.saude.ria.fhir.md)

### Examples

* [example-RIA-R (Bundle)](Bundle-example-RIA-R.md)
