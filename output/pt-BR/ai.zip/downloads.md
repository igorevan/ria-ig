# Downloads - Guia de Implementação do Registro de Imunobiológico Administrado (RIA) da RNDS v1.0.0

## Downloads

 Baixe todo o Guia de Implementação [aqui](../full-ig.zip) 

* Artifact Definitions: Examples
  * [XML](../definitions.xml.zip): [XML](../examples.xml.zip)
  * [JSON](../definitions.json.zip): [JSON](../examples.json.zip)
  * [Turtle](../definitions.ttl.zip): [Turtle](../examples.ttl.zip)

 **Package** [`package.tgz`](../package.tgz) 

