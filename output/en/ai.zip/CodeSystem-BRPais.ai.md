# País (CodeSystem) - Guia de Implementação do Registro de Imunobiológico Administrado (RIA) da RNDS v1.0.0-release

## CodeSystem: País (CodeSystem) 

 
Códigos para representação de países. 

This Code system is referenced in the definition of the following value sets:

* [BRPais](ValueSet-BRPais-1.0.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BRPais",
  "language" : "pt-BR",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-wg",
    "valueCode" : "ehr"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1,
    "_valueInteger" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/ria/1.0.0/ImplementationGuide/br.gov.saude.ria.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "normative",
    "_valueCode" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-conformance-derivedFrom",
        "valueCanonical" : "https://fhir.saude.gov.br/fhir/r4/ria/1.0.0/ImplementationGuide/br.gov.saude.ria.fhir"
      }]
    }
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-normative-version",
    "valueCode" : "4.0.1"
  }],
  "url" : "http://www.saude.gov.br/fhir/r4/CodeSystem/BRPais",
  "version" : "1.0.0-release",
  "name" : "BRPais",
  "title" : "País (CodeSystem)",
  "status" : "active",
  "experimental" : false,
  "date" : "2020-03-13T21:12:16.4900634+00:00",
  "publisher" : "Ministério da Saúde do Brasil",
  "contact" : [{
    "name" : "Ministério da Saúde do Brasil",
    "telecom" : [{
      "system" : "url",
      "value" : "http://www.saude.gov.br"
    },
    {
      "system" : "email",
      "value" : "cgiis.datasus@saude.gov.br"
    }]
  }],
  "description" : "Códigos para representação de países.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BR"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "concept" : [{
    "code" : "10",
    "display" : "BRASIL"
  },
  {
    "code" : "20",
    "display" : "RESERVADO"
  },
  {
    "code" : "21",
    "display" : "ARGENTINA"
  },
  {
    "code" : "22",
    "display" : "BOLIVIA"
  },
  {
    "code" : "23",
    "display" : "CHILE"
  },
  {
    "code" : "24",
    "display" : "PARAGUAI"
  },
  {
    "code" : "25",
    "display" : "URUGUAI"
  },
  {
    "code" : "26",
    "display" : "COLOMBIA"
  },
  {
    "code" : "27",
    "display" : "EQUADOR"
  },
  {
    "code" : "28",
    "display" : "ANTIGUA E. DEP. BARBUDA"
  },
  {
    "code" : "29",
    "display" : "ANTILHAS HOLANDESAS"
  },
  {
    "code" : "30",
    "display" : "ALEMANHA"
  },
  {
    "code" : "31",
    "display" : "BELGICA"
  },
  {
    "code" : "32",
    "display" : "GRA-BRETANHA"
  },
  {
    "code" : "33",
    "display" : "ARUBA"
  },
  {
    "code" : "34",
    "display" : "CANADA"
  },
  {
    "code" : "35",
    "display" : "ESPANHA"
  },
  {
    "code" : "36",
    "display" : "ESTADOS UNIDOS DA AMERICA (EUA)"
  },
  {
    "code" : "37",
    "display" : "FRANCA"
  },
  {
    "code" : "38",
    "display" : "SUICA"
  },
  {
    "code" : "39",
    "display" : "ITALIA"
  },
  {
    "code" : "40",
    "display" : "COMUNIDADE DAS BAHAMAS"
  },
  {
    "code" : "41",
    "display" : "JAPAO"
  },
  {
    "code" : "42",
    "display" : "CHINA"
  },
  {
    "code" : "43",
    "display" : "COREIA"
  },
  {
    "code" : "44",
    "display" : "BARBADOS"
  },
  {
    "code" : "45",
    "display" : "PORTUGAL"
  },
  {
    "code" : "46",
    "display" : "BELIZE"
  },
  {
    "code" : "47",
    "display" : "ILHAS TURKS E CAICOS"
  },
  {
    "code" : "48",
    "display" : "RESERVADO"
  },
  {
    "code" : "49",
    "display" : "RESERVADO"
  },
  {
    "code" : "50",
    "display" : "RESERVADO"
  },
  {
    "code" : "51",
    "display" : "COSTA RICA"
  },
  {
    "code" : "52",
    "display" : "CUBA"
  },
  {
    "code" : "53",
    "display" : "CURACAO"
  },
  {
    "code" : "54",
    "display" : "COMUNIDADE DOMINICANA"
  },
  {
    "code" : "55",
    "display" : "REPUBLICA DOMINICANA"
  },
  {
    "code" : "56",
    "display" : "REPUBLICA DE EL SALVADOR"
  },
  {
    "code" : "57",
    "display" : "ESTADOS ASSOC. DAS ANTILHAS"
  },
  {
    "code" : "58",
    "display" : "ILHAS FALKLANDS"
  },
  {
    "code" : "59",
    "display" : "GRANADA"
  },
  {
    "code" : "60",
    "display" : "ILHAS GUADALUPE"
  },
  {
    "code" : "61",
    "display" : "GUATEMALA"
  },
  {
    "code" : "62",
    "display" : "REPUBLICA DO HAITI"
  },
  {
    "code" : "63",
    "display" : "HONDURAS BRITANICAS"
  },
  {
    "code" : "64",
    "display" : "HONDURAS"
  },
  {
    "code" : "65",
    "display" : "ILHAS SERRANAS"
  },
  {
    "code" : "66",
    "display" : "JAMAICA"
  },
  {
    "code" : "67",
    "display" : "ILHAS MALVINAS"
  },
  {
    "code" : "68",
    "display" : "MARTINICA"
  },
  {
    "code" : "69",
    "display" : "ILHA MILHOS"
  },
  {
    "code" : "70",
    "display" : "MONTE SERRAT"
  },
  {
    "code" : "71",
    "display" : "NICARAGUA"
  },
  {
    "code" : "72",
    "display" : "PANAMA"
  },
  {
    "code" : "73",
    "display" : "PANAMA(ZONA DO CANAL)"
  },
  {
    "code" : "74",
    "display" : "PORTO RICO"
  },
  {
    "code" : "75",
    "display" : "QUITASUENO"
  },
  {
    "code" : "76",
    "display" : "RONCADOR"
  },
  {
    "code" : "77",
    "display" : "SANTA LUCIA"
  },
  {
    "code" : "78",
    "display" : "SAO CRISTOVAO"
  },
  {
    "code" : "79",
    "display" : "SAO VICENTE"
  },
  {
    "code" : "80",
    "display" : "ILHAS TURCA"
  },
  {
    "code" : "81",
    "display" : "ILHAS VIRGENS BRITANICAS"
  },
  {
    "code" : "82",
    "display" : "ILHAS VIRGENS AMERICANAS"
  },
  {
    "code" : "83",
    "display" : "BERMUDAS"
  },
  {
    "code" : "84",
    "display" : "GROENLANDIA"
  },
  {
    "code" : "85",
    "display" : "MEXICO"
  },
  {
    "code" : "86",
    "display" : "ST. PIERRE ET MIQUELON"
  },
  {
    "code" : "87",
    "display" : "GUIANA FRANCESA"
  },
  {
    "code" : "88",
    "display" : "REPUBLICA GUIANA"
  },
  {
    "code" : "89",
    "display" : "PERU"
  },
  {
    "code" : "90",
    "display" : "SURINAME"
  },
  {
    "code" : "91",
    "display" : "TRINIDAD E TOBAGO"
  },
  {
    "code" : "92",
    "display" : "VENEZUELA"
  },
  {
    "code" : "93",
    "display" : "ALBANIA"
  },
  {
    "code" : "94",
    "display" : "ANDORRA"
  },
  {
    "code" : "95",
    "display" : "AUSTRIA"
  },
  {
    "code" : "96",
    "display" : "BULGARIA"
  },
  {
    "code" : "97",
    "display" : "CHIPRE"
  },
  {
    "code" : "98",
    "display" : "DINAMARCA"
  },
  {
    "code" : "99",
    "display" : "EIRE"
  },
  {
    "code" : "100",
    "display" : "ESCOCIA"
  },
  {
    "code" : "101",
    "display" : "ILHAS FAROES"
  },
  {
    "code" : "102",
    "display" : "FINLANDIA"
  },
  {
    "code" : "103",
    "display" : "GIBRALTAR"
  },
  {
    "code" : "104",
    "display" : "GRECIA"
  },
  {
    "code" : "105",
    "display" : "HOLANDA"
  },
  {
    "code" : "106",
    "display" : "HUNGRIA"
  },
  {
    "code" : "107",
    "display" : "ILHAS BALEARES"
  },
  {
    "code" : "108",
    "display" : "ILHAS COSMOLEDO (LOMORES)"
  },
  {
    "code" : "109",
    "display" : "ILHAS DO CANAL"
  },
  {
    "code" : "110",
    "display" : "INGLATERRA"
  },
  {
    "code" : "111",
    "display" : "IRLANDA DO NORTE"
  },
  {
    "code" : "112",
    "display" : "IRLANDA"
  },
  {
    "code" : "113",
    "display" : "ISLANDIA"
  },
  {
    "code" : "114",
    "display" : "IUGOSLAVIA"
  },
  {
    "code" : "115",
    "display" : "LIECHTENSTEIN"
  },
  {
    "code" : "116",
    "display" : "LUXEMBURGO"
  },
  {
    "code" : "117",
    "display" : "ILHAS DE MAN"
  },
  {
    "code" : "118",
    "display" : "MONACO"
  },
  {
    "code" : "119",
    "display" : "NORUEGA"
  },
  {
    "code" : "120",
    "display" : "REPUBLICA DE MALTA"
  },
  {
    "code" : "121",
    "display" : "PAIS DE GALES"
  },
  {
    "code" : "122",
    "display" : "PAISES BAIXOS"
  },
  {
    "code" : "123",
    "display" : "POLONIA"
  },
  {
    "code" : "124",
    "display" : "ROMENIA"
  },
  {
    "code" : "125",
    "display" : "SAN MARINO"
  },
  {
    "code" : "126",
    "display" : "SUECIA"
  },
  {
    "code" : "127",
    "display" : "SVALBARD E JAN MAYER,IS"
  },
  {
    "code" : "128",
    "display" : "TCHECOSLOVAQUIA"
  },
  {
    "code" : "129",
    "display" : "ESTADO DA CIDADE DO VATICANO"
  },
  {
    "code" : "130",
    "display" : "CROACIA"
  },
  {
    "code" : "131",
    "display" : "SERVIA"
  },
  {
    "code" : "132",
    "display" : "ESLOVENIA"
  },
  {
    "code" : "133",
    "display" : "REPUBLICA DA MACEDONIA"
  },
  {
    "code" : "134",
    "display" : "BOSNIA HERZEGOVINA"
  },
  {
    "code" : "135",
    "display" : "REPUBLICA TCHECA"
  },
  {
    "code" : "136",
    "display" : "ESLOVAQUIA"
  },
  {
    "code" : "137",
    "display" : "MONTENEGRO"
  },
  {
    "code" : "138",
    "display" : "AZERBAIJAO"
  },
  {
    "code" : "139",
    "display" : "BASHKISTA"
  },
  {
    "code" : "140",
    "display" : "REPUBLICA DA BIELORRUSSIA"
  },
  {
    "code" : "141",
    "display" : "BURYAT"
  },
  {
    "code" : "142",
    "display" : "CARELIA"
  },
  {
    "code" : "143",
    "display" : "CAZAQUISTAO"
  },
  {
    "code" : "144",
    "display" : "CHECHEN INGUSTH"
  },
  {
    "code" : "145",
    "display" : "CHUVASH"
  },
  {
    "code" : "146",
    "display" : "DAGESTA"
  },
  {
    "code" : "147",
    "display" : "ESTONIA"
  },
  {
    "code" : "148",
    "display" : "GEORGIA"
  },
  {
    "code" : "149",
    "display" : "GORNO ALTAI"
  },
  {
    "code" : "150",
    "display" : "KABARDINO BALKAR"
  },
  {
    "code" : "151",
    "display" : "KALMIR"
  },
  {
    "code" : "152",
    "display" : "KARACHAEVOCHERKESS"
  },
  {
    "code" : "153",
    "display" : "KHAKASS"
  },
  {
    "code" : "154",
    "display" : "KOMI"
  },
  {
    "code" : "155",
    "display" : "LETONIA"
  },
  {
    "code" : "156",
    "display" : "LITUANIA"
  },
  {
    "code" : "157",
    "display" : "MARI"
  },
  {
    "code" : "158",
    "display" : "MOLDAVIA"
  },
  {
    "code" : "159",
    "display" : "OSSETIA SETENTRIONAL"
  },
  {
    "code" : "160",
    "display" : "QUIRGUISTAO"
  },
  {
    "code" : "161",
    "display" : "TADJIQUISTAO"
  },
  {
    "code" : "162",
    "display" : "TARTARIA"
  },
  {
    "code" : "163",
    "display" : "TURCOMENISTAO"
  },
  {
    "code" : "164",
    "display" : "TUVIN"
  },
  {
    "code" : "165",
    "display" : "UCRANIA"
  },
  {
    "code" : "166",
    "display" : "UDMURT"
  },
  {
    "code" : "167",
    "display" : "UNIAO SOVIETICA"
  },
  {
    "code" : "168",
    "display" : "UZBEQUISTAO"
  },
  {
    "code" : "169",
    "display" : "YAKUT"
  },
  {
    "code" : "170",
    "display" : "ABISSINIA"
  },
  {
    "code" : "171",
    "display" : "ACORES"
  },
  {
    "code" : "172",
    "display" : "AFAR FRANCES"
  },
  {
    "code" : "173",
    "display" : "REPUBLICA DA AFRICA DO SUL"
  },
  {
    "code" : "174",
    "display" : "ALTA VOLTA"
  },
  {
    "code" : "175",
    "display" : "ANGOLA"
  },
  {
    "code" : "176",
    "display" : "ARGELIA"
  },
  {
    "code" : "177",
    "display" : "BECHUANALANDIA"
  },
  {
    "code" : "178",
    "display" : "BENIN"
  },
  {
    "code" : "179",
    "display" : "BOTSUANA"
  },
  {
    "code" : "180",
    "display" : "BURUNDI"
  },
  {
    "code" : "181",
    "display" : "CAMAROES"
  },
  {
    "code" : "182",
    "display" : "CEUTA E MELILLA"
  },
  {
    "code" : "183",
    "display" : "CHADE"
  },
  {
    "code" : "184",
    "display" : "ILHAS COMORES"
  },
  {
    "code" : "185",
    "display" : "CONGO"
  },
  {
    "code" : "186",
    "display" : "COSTA DO MARFIM"
  },
  {
    "code" : "187",
    "display" : "DAOME"
  },
  {
    "code" : "188",
    "display" : "DJIBUTI"
  },
  {
    "code" : "189",
    "display" : "REPUBLICA ARABE DO EGITO"
  },
  {
    "code" : "190",
    "display" : "ETIOPIA"
  },
  {
    "code" : "191",
    "display" : "REPUBLICA DO GABAO"
  },
  {
    "code" : "192",
    "display" : "GAMBIA"
  },
  {
    "code" : "193",
    "display" : "GANA"
  },
  {
    "code" : "194",
    "display" : "GAZA"
  },
  {
    "code" : "195",
    "display" : "GUINE"
  },
  {
    "code" : "196",
    "display" : "GUINE EQUATORIAL"
  },
  {
    "code" : "197",
    "display" : "IFNI"
  },
  {
    "code" : "198",
    "display" : "ASCENSAO E TRISTAO DA CUNHA,IS"
  },
  {
    "code" : "199",
    "display" : "ILHAS CANARIAS"
  },
  {
    "code" : "200",
    "display" : "LESOTO"
  },
  {
    "code" : "201",
    "display" : "LIBERIA"
  },
  {
    "code" : "202",
    "display" : "LIBIA"
  },
  {
    "code" : "203",
    "display" : "MADEIRA"
  },
  {
    "code" : "204",
    "display" : "MALAWI"
  },
  {
    "code" : "205",
    "display" : "MADAGASCAR"
  },
  {
    "code" : "206",
    "display" : "MALI"
  },
  {
    "code" : "207",
    "display" : "MARROCOS"
  },
  {
    "code" : "208",
    "display" : "MAURICIO"
  },
  {
    "code" : "209",
    "display" : "MAURITANIA"
  },
  {
    "code" : "210",
    "display" : "MOCAMBIQUE"
  },
  {
    "code" : "211",
    "display" : "NGUANE"
  },
  {
    "code" : "212",
    "display" : "REPUBLICA DO NIGER"
  },
  {
    "code" : "213",
    "display" : "NIGERIA"
  },
  {
    "code" : "214",
    "display" : "PAPUA NOVA GUINE"
  },
  {
    "code" : "215",
    "display" : "PRACAS NORTE AFRICANAS"
  },
  {
    "code" : "216",
    "display" : "PROTETOR DO SUDOESTE AFRICANO"
  },
  {
    "code" : "217",
    "display" : "QUENIA"
  },
  {
    "code" : "218",
    "display" : "REPUBLICA CENTRO AFRICANA"
  },
  {
    "code" : "219",
    "display" : "REUNIAO"
  },
  {
    "code" : "220",
    "display" : "RODESIA (ZIMBABWE)"
  },
  {
    "code" : "221",
    "display" : "RUANDA"
  },
  {
    "code" : "222",
    "display" : "SAARA ESPANHOL"
  },
  {
    "code" : "223",
    "display" : "SANTA HELENA"
  },
  {
    "code" : "224",
    "display" : "SAO TOME E PRINCIPE"
  },
  {
    "code" : "225",
    "display" : "SEYCHELLES"
  },
  {
    "code" : "226",
    "display" : "SERRA LEOA"
  },
  {
    "code" : "227",
    "display" : "SOMALIA, REPUBLICA"
  },
  {
    "code" : "228",
    "display" : "SUAZILANDIA"
  },
  {
    "code" : "229",
    "display" : "SUDAO"
  },
  {
    "code" : "230",
    "display" : "TANGANICA"
  },
  {
    "code" : "231",
    "display" : "TERRIT. BRITANICO DO OCEANO INDICO"
  },
  {
    "code" : "232",
    "display" : "TRANSKEI"
  },
  {
    "code" : "233",
    "display" : "TOGO"
  },
  {
    "code" : "234",
    "display" : "TUNISIA"
  },
  {
    "code" : "235",
    "display" : "UGANDA"
  },
  {
    "code" : "236",
    "display" : "ZAIRE"
  },
  {
    "code" : "237",
    "display" : "ZAMBIA"
  },
  {
    "code" : "238",
    "display" : "BURKINA FASSO"
  },
  {
    "code" : "239",
    "display" : "ZIMBABWE"
  },
  {
    "code" : "240",
    "display" : "NAMIBIA"
  },
  {
    "code" : "241",
    "display" : "AFEGANISTAO"
  },
  {
    "code" : "242",
    "display" : "ARABIA SAUDITA"
  },
  {
    "code" : "243",
    "display" : "BAHREIN"
  },
  {
    "code" : "244",
    "display" : "BIRMANIA"
  },
  {
    "code" : "245",
    "display" : "BRUNEI"
  },
  {
    "code" : "246",
    "display" : "BHUTAN"
  },
  {
    "code" : "247",
    "display" : "CATAR"
  },
  {
    "code" : "248",
    "display" : "CEILAO"
  },
  {
    "code" : "249",
    "display" : "CHINA (TAIWAN)"
  },
  {
    "code" : "250",
    "display" : "COVEITE"
  },
  {
    "code" : "251",
    "display" : "EMIRADOS ARABES UNIDOS"
  },
  {
    "code" : "252",
    "display" : "FILIPINAS"
  },
  {
    "code" : "253",
    "display" : "HONG-KONG"
  },
  {
    "code" : "254",
    "display" : "IEMEN"
  },
  {
    "code" : "255",
    "display" : "INDIA"
  },
  {
    "code" : "256",
    "display" : "INDONESIA"
  },
  {
    "code" : "257",
    "display" : "IRA"
  },
  {
    "code" : "258",
    "display" : "IRAQUE"
  },
  {
    "code" : "259",
    "display" : "ISRAEL"
  },
  {
    "code" : "260",
    "display" : "JORDANIA"
  },
  {
    "code" : "261",
    "display" : "KMER/CAMBOJA"
  },
  {
    "code" : "262",
    "display" : "KUWAIT"
  },
  {
    "code" : "263",
    "display" : "LAOS"
  },
  {
    "code" : "264",
    "display" : "LIBANO"
  },
  {
    "code" : "265",
    "display" : "MACAU"
  },
  {
    "code" : "266",
    "display" : "MALASIA"
  },
  {
    "code" : "267",
    "display" : "MALDIVAS,IS"
  },
  {
    "code" : "268",
    "display" : "MASCATE"
  },
  {
    "code" : "269",
    "display" : "MONGOLIA"
  },
  {
    "code" : "270",
    "display" : "NEPAL"
  },
  {
    "code" : "271",
    "display" : "OMAN"
  },
  {
    "code" : "272",
    "display" : "PALESTINA"
  },
  {
    "code" : "273",
    "display" : "PAQUISTAO"
  },
  {
    "code" : "274",
    "display" : "RUIQUIU,IS"
  },
  {
    "code" : "275",
    "display" : "CINGAPURA"
  },
  {
    "code" : "276",
    "display" : "SEQUIN"
  },
  {
    "code" : "277",
    "display" : "SIRIA"
  },
  {
    "code" : "278",
    "display" : "SRI-LANKA"
  },
  {
    "code" : "279",
    "display" : "TAILANDIA"
  },
  {
    "code" : "280",
    "display" : "TREGUA, ESTADO"
  },
  {
    "code" : "281",
    "display" : "TURQUIA"
  },
  {
    "code" : "282",
    "display" : "VIETNA DO NORTE"
  },
  {
    "code" : "283",
    "display" : "VIETNA DO SUL"
  },
  {
    "code" : "284",
    "display" : "MIANMA"
  },
  {
    "code" : "285",
    "display" : "ARQUIPELAGO MANAHIKI"
  },
  {
    "code" : "286",
    "display" : "ARQUIPELAGO MIDWAY"
  },
  {
    "code" : "287",
    "display" : "ASHMORE E CARTIER"
  },
  {
    "code" : "288",
    "display" : "AUSTRALIA"
  },
  {
    "code" : "289",
    "display" : "ARQUIPELAGO DE BISMARK"
  },
  {
    "code" : "290",
    "display" : "ILHAS COOK"
  },
  {
    "code" : "291",
    "display" : "REPUBLICA DE FIJI"
  },
  {
    "code" : "292",
    "display" : "GUAM"
  },
  {
    "code" : "293",
    "display" : "ILHAS BAKER"
  },
  {
    "code" : "294",
    "display" : "ILHAS CANTAO E ENDERBURG"
  },
  {
    "code" : "295",
    "display" : "ILHAS CAROLINAS"
  },
  {
    "code" : "296",
    "display" : "ILHAS DO PACIFICO"
  },
  {
    "code" : "297",
    "display" : "ILHAS CHRISTMAS"
  },
  {
    "code" : "298",
    "display" : "ILHAS GILBERT"
  },
  {
    "code" : "299",
    "display" : "ILHAS HOWLAND E JARVIS"
  },
  {
    "code" : "300",
    "display" : "ILHA JOHNSTON E SAND"
  },
  {
    "code" : "301",
    "display" : "ILHAS KINGMAN REEF"
  },
  {
    "code" : "302",
    "display" : "ILHAS MACQUAIRE"
  },
  {
    "code" : "303",
    "display" : "ILHAS MARIANAS"
  },
  {
    "code" : "304",
    "display" : "ILHAS MARSHALL"
  },
  {
    "code" : "305",
    "display" : "ILHAS MACDONAL E HEARD"
  },
  {
    "code" : "306",
    "display" : "ILHAS NIUE"
  },
  {
    "code" : "307",
    "display" : "ILHAS NORFOLK"
  },
  {
    "code" : "308",
    "display" : "ILHAS PALAU"
  },
  {
    "code" : "309",
    "display" : "ILHAS SALOMAO"
  },
  {
    "code" : "310",
    "display" : "ILHAS TOKELAU"
  },
  {
    "code" : "311",
    "display" : "ILHAS WAKE"
  },
  {
    "code" : "312",
    "display" : "KALIMATAN"
  },
  {
    "code" : "313",
    "display" : "ILHAS LINHA"
  },
  {
    "code" : "314",
    "display" : "NAURU"
  },
  {
    "code" : "315",
    "display" : "ILHAS NOVA CALEDONIA"
  },
  {
    "code" : "316",
    "display" : "NOVA GUINE"
  },
  {
    "code" : "317",
    "display" : "NOVA ZELANDIA"
  },
  {
    "code" : "318",
    "display" : "ILHAS NOVAS HEBRIDAS"
  },
  {
    "code" : "319",
    "display" : "TERRITORIO DE PAPUA"
  },
  {
    "code" : "320",
    "display" : "ILHAS PASCOA"
  },
  {
    "code" : "321",
    "display" : "ILHAS PITCAIRIN"
  },
  {
    "code" : "322",
    "display" : "POLINESIA FRANCESA"
  },
  {
    "code" : "323",
    "display" : "SABAH"
  },
  {
    "code" : "324",
    "display" : "SAMOA AMERICANA"
  },
  {
    "code" : "325",
    "display" : "SAMOA OCIDENTAL"
  },
  {
    "code" : "326",
    "display" : "ILHAS SANTA CRUZ"
  },
  {
    "code" : "327",
    "display" : "SARAWAK"
  },
  {
    "code" : "328",
    "display" : "TERRITORIO DE COCOS"
  },
  {
    "code" : "329",
    "display" : "TIMOR"
  },
  {
    "code" : "330",
    "display" : "TONGA"
  },
  {
    "code" : "331",
    "display" : "TUVALU"
  },
  {
    "code" : "332",
    "display" : "ILHAS WALLIS E FUTUNA"
  },
  {
    "code" : "333",
    "display" : "ANTARTICO BRITANICO, TERRITORIO"
  },
  {
    "code" : "334",
    "display" : "ANTARTICA FRANCESA"
  },
  {
    "code" : "335",
    "display" : "TERR. ANTARTICO DA AUSTRALIA"
  },
  {
    "code" : "336",
    "display" : "ANTARTICO CHILENO"
  },
  {
    "code" : "337",
    "display" : "ANTARTICO ARGENTINO"
  },
  {
    "code" : "338",
    "display" : "ANTARTICO NORUEGUES"
  },
  {
    "code" : "339",
    "display" : "APATRIDA"
  },
  {
    "code" : "340",
    "display" : "DEPENDENCIA DE ROSS"
  },
  {
    "code" : "341",
    "display" : "TERRAS AUSTRAIS"
  },
  {
    "code" : "342",
    "display" : "BANGLADESH"
  },
  {
    "code" : "343",
    "display" : "CABO VERDE"
  },
  {
    "code" : "344",
    "display" : "GUINE BISSAU"
  },
  {
    "code" : "345",
    "display" : "IEMEN DO SUL"
  },
  {
    "code" : "346",
    "display" : "KARA KALPAK"
  },
  {
    "code" : "347",
    "display" : "ARMENIA"
  },
  {
    "code" : "348",
    "display" : "RUSSIA"
  },
  {
    "code" : "349",
    "display" : "SENEGAL"
  },
  {
    "code" : "350",
    "display" : "TANZANIA"
  },
  {
    "code" : "351",
    "display" : "MALAUI"
  },
  {
    "code" : "352",
    "display" : "REPÚBLICA DO SUDÃO DO SUL"
  },
  {
    "code" : "353",
    "display" : "ERITREIA"
  },
  {
    "code" : "354",
    "display" : "DOMINICA"
  },
  {
    "code" : "355",
    "display" : "COREIA, REPUBLICA DA (COREIA DO SUL)"
  },
  {
    "code" : "356",
    "display" : "CONGO, REPUBLICA DO (BRAZZAVILLE)"
  },
  {
    "code" : "357",
    "display" : "ANGUILLA"
  },
  {
    "code" : "358",
    "display" : "ILHAS CAYMAN"
  },
  {
    "code" : "359",
    "display" : "ILHAS DE GUERNSEY"
  },
  {
    "code" : "360",
    "display" : "ILHAS DE JERSEY"
  },
  {
    "code" : "361",
    "display" : "ILHAS GEORGIA DO SUL E ILHAS SANDWICH DO SUL"
  },
  {
    "code" : "362",
    "display" : "MAYOTTE, ILHA"
  },
  {
    "code" : "363",
    "display" : "QUIRIBATI"
  }]
}

```
